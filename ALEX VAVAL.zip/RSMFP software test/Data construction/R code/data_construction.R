################################################


# _______________________  Task 2. Data Construction  _________________________

#.  Goal: Construction of the datasets that will be used for the tables and graphs.
#.        With the different units of analysis, HH and job. The treatment
#.        will also be merged here.


#. Input: baseline_clean, GEM_Treatment_Status


#. Output: hh_analysis, job_analysis

################################################


########  0. Packages, directories  ########


# List of packages to install
list_packages <- c(
  "dplyr", "ggplot2", "tidyr", "stargazer", "haven", "tidylog", "sandwich",
  "haven", "styler", "labelled", "skimr", "ids", "uuid", "stringr",
  "pastecs", "broom","knitr","huxtable","modelsummary", "ggthemes", "data.table",
  "flextable", "officer","reporter","janitor","gt","foreign"
)


# Install if not installed and require:
for (package in list_packages) {
  if (!require(package, character.only = TRUE)) {
    install.packages(package)
    library(package, character.only = TRUE)
  } else {
    library(package, character.only = TRUE)
  }
}

options(scipen = 999) # to not have numbers in scientific format


setwd("/Users/avpc/Desktop/RSMFP software test/Data construction") #setting working directory


#path R folder
R_code_path <- "R code"

#path output folder
input_folder_path <- "Input"

#path output folder
output_folder_path <- "Output"

#path dataset folder 
output_dataset <- file.path(output_folder_path , "dataset")

#path documentation folder 
output_documentation <- file.path(output_folder_path , "documentation")


#________________________________________________
######## Task 2. Data construction  ########
#________________________________________________

#. Steps: 
#. In this section I will construct the datasets
#. needed for tasks two, creating the variables
#. needed and merging with treatment dataframe.

# Calling data
baseline_clean <- read.csv(file.path(input_folder_path,"baseline_clean.csv")) %>% # baseline clean
  select(-X) # WHY IS THE X THERE, ITS THE CSV FUNCTION !!!!
  
labels_var_baseline <- data.frame( 
  
  look_for(baseline_clean)) # labels and varnames


treat_stat<- 
  read_dta("~/Desktop/RSMFP software test/Data Cleaning/Input/GEM_Treatment_Status.dta") #treatment
  

#  1. Constructing HH level dataset
# constructing the total savings var and exchange rate var
hh_analysis <- baseline_clean %>%
  
  filter(HHID!=".") %>% # Getting rid of HH with no ID pending checking with supervisor
  
  mutate(usd_ksh = 135) %>%
  
  mutate(cash_saving_usd = s02_cash_savings/usd_ksh,
         jewlery_saving_usd = s04_jewellery_savings_value/usd_ksh) %>%
  
  group_by(HHID) %>%
  
  mutate(total_saving_usd = 
           sum(cash_saving_usd, jewlery_saving_usd,na.rm=T)) %>%
  
  ungroup() %>%
  
  select (HHID, cash_saving_usd, jewlery_saving_usd, total_saving_usd, usd_ksh,
          everything(.)) %>%
  
  merge(treat_stat, by ="HHID") # In the merging I lose information 7 obs, counting the ones I filtered

  
  
  #labeling
  labels(hh_analysis ) <- 
    c( HHID = "Respondent ID", 
       cash_saving_usd = "Savings in cash (USD)",
       jewlery_saving_usd = "Savings in Jewlery (USD)" , 
       usd_ksh = "Exchange rate KSH/USD" ,
       total_saving_usd_usd = "Total savings (USD)",
       treatment = "Treatment status (0 = NO, 1 = YES)") #adding missing labels for variables
  
  
  
  
  
  

#  2. Constructing job level dataset.
#  I will create 3 datasets based on the 3,
# the 3 jobs that there are.
# then I will pivot to have that as the unit 
# of analysis then merge with treatment variable
# and across job type.
# I select only the relevant variables!


# Job 1
job_1 <- baseline_clean %>%
  
  filter(HHID!=".")  %>%

  select(w02_paid_in_cash_job1, w07_hours_job1, HHID) %>%
  
  mutate(job_type = 1) %>% #create an indicator for the job type
  
  rename( job = w02_paid_in_cash_job1,
          
          hours = w07_hours_job1)%>%
  
  select(job_type, HHID, everything())


# Job 2
job_2 <- baseline_clean  %>%
  
  filter(HHID!=".") %>%
  
  select(w02_paid_in_cash_job2, w07_hours_job2, HHID) %>%
  
  mutate(job_type = 2) %>%  #create an indicator for the job type
  
  rename( job = w02_paid_in_cash_job2,
          
          hours = w07_hours_job2)%>%
  
  select(job_type, HHID, everything())


# Job 3
job_3 <- baseline_clean  %>%
  
  filter(HHID!=".")  %>%
  
  select(w02_paid_in_cash_job3, w07_hours_job3, HHID,) %>%
  
  mutate(job_type = 3) %>%  #create an indicator for the job type
  
  rename( job = w02_paid_in_cash_job3,
          
          hours = w07_hours_job3) %>%
  
  select(job_type, HHID, everything())


# Unpaid work
unpaid_work <- baseline_clean   %>%
  
  filter(HHID!=".") %>%
  
  select(w15_work_not_paid, w20_hours_unpaid_job99, HHID) %>%
  
  mutate(job_type = 4) %>%
  
  mutate(job = NA) %>% # I would use the type of unpaid work here but dont have the time
  
  rename( hours = w20_hours_unpaid_job99) %>%
  
  select( job_type, HHID,job, hours)

  
  # Creating the final data set with treatment var
  job_analysis <-
    
    rbind(job_1, job_2, job_3, unpaid_work) %>%
    
    merge( treat_stat, by = "HHID")
  
  
  #labeling
  labels(job_analysis) <- 
    c( HHID = "Respondent ID", job_type = "Type of Job",
       hours = "Hours working (paid/unpaid)" , 
       job = "work sector",
       treatment = "Treatment status (0 = NO, 1 = YES)") #adding missing labels for variables
  
  #Labels for job type
  val_label(job_analysis$job_type, 1) <- "Paid Job 1"
  val_label(job_analysis$job_type, 2) <- "Paid Job 2"
  val_label(job_analysis$job_type, 3) <- "Paid Job 3"
  val_label(job_analysis$job_type, 4) <- "Unpaid work"
  
  
  
  
  ######## Saving ########
  
  # Saving datasets
  write.csv(hh_analysis,file.path(output_dataset,"hh_analysis.csv"))
  

  write.csv(job_analysis,file.path(output_dataset,"job_analysis.csv"))



