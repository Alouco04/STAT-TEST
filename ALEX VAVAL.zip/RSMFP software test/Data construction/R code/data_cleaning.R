################################################


# _______________________  Task 1. Data Cleaning  _________________________

#.  Goal:


#. Input: 


#. Output: 

################################################


########  0. Packages, directories  ########


# List of packages to install
list_packages <- c(
  "dplyr", "ggplot2", "tidyr", "stargazer", "haven", "tidylog", "sandwich",
  "haven", "styler", "labelled", "skimr", "ids", "uuid", "stringr",
  "pastecs", "broom","knitr","huxtable","modelsummary", "ggthemes", "data.table",
  "flextable", "officer","reporter"
)


# Install if not installed and require:
for (package in list_packages) {
  if (!require(package, character.only = TRUE)) {
    install.packages(package)
    library(package, character.only = TRUE)
  } else {
    library(package, character.only = TRUE)
  }
}

options(scipen = 999) # to not have numbers in scientific format


setwd("/Users/avpc/Desktop/RSMFP software test") #setting working directory

dir_name <- "Data Cleaning" #Folder name


# Check if the directory exists
if (!dir.exists(dir_name )) {
  # If the directory doesn't exist, create it
  dir.create(dir_name )
  cat("Directory", dir_name , "has been created.\n")
} else {
  cat("Directory", dir_name, "already exists.\n")
}

# Set the newly created directory as your working directory
setwd(dir_name )

# Define function to create output folder
create_folder <- function(folder_path) {
  if (!dir.exists(folder_path)) {
    dir.create(folder_path)
  }
}

#Creating R folder
R_code_path <- "R code"
create_folder(R_code_path) # Reader wull have to manually put this script in the Rcode rile


#Creating output folder
input_folder_path <- "Input"
create_folder(input_folder_path)


#Creating output folder
output_folder_path <- "Output"
create_folder(output_folder_path)

#Creating dataset folder 
output_dataset <- file.path(output_folder_path , "dataset")
create_folder(output_dataset)

#Creating documentation folder 
output_documentation <- file.path(output_folder_path , "documentation")
create_folder(output_documentation)




#________________________________________________
######## Task 1. Data cleaning  ########
#________________________________________________

#. Goal : 
#. Steps: 
#. 1 -
#. 2 -
#. 3 - 
#. OUTPUT : 


# Calling the raw data
path_file<- file.choose() #manually select it based on where it is on the computer
path_file <- read_dta(path_file) 


# Creating seperate folder on which data cleaning comments are
sink(file.path(output_documentation , "Comments of Data cleaning"))

cat("Hello, this is some output that I want to save.")




sink()




#Notes:
# Do not rename variables during cleaning
# WHEN YOU HAVE MULTIPLE UNITS OF OBSERVATION CREATE DIFFERENT TABLES
# keep all the variables in the cleaning
# create folder structures Possibly sharing multiple R scripts




#________________________________________________
######## Task 2. Descriptive Statistics  ########
#________________________________________________

#. Goal : 
#. Steps: 
#. 1 -
#. 2 -
#. 3 - 
#. OUTPUT : 







# seeing label values (VARIABLE)
val_labels(df) 

#SETTING LABEL 

# Adding labels for this new dataframe
var_label(df) <- list(
  var_name1 = "Label 1",
  var_name2 = "label 2",....
)


# Example of histogram plot
p <- ggplot(rw_panel_did, aes(x = fcs) ) + geom_histogram() + # type of plot
  
  xlab("Xlabel") + ylab("ylab") + # axis labels
  
  ggtitle("test") + theme(plot.title = element_text(hjust = 0.5)) + # title
  
  ggsave("output_folder/my_ggplot.pdf", plot = p) # Save the plot as a PDF


# Balance table code

#  Creating a function to create balance table
create_balance_table <- function(data, treatment_var, outcome_vars, significance_levels = c(0.1, 0.05, 0.01)) {
  
  # Filter data for treated and control groups
  treated <- data %>% filter({{treatment_var}} == 1)
  control <- data %>% filter({{treatment_var}} == 0)
  
  # Initialize an empty table
  balance_table <- data.frame(Variable = character(), 
                              Treated = numeric(), 
                              Control = numeric(), 
                              Difference = numeric(), 
                              `p-value` = numeric(), 
                              Significance = character(),
                              stringsAsFactors = FALSE)
  
  # Iterate over outcome variables
  for (var in outcome_vars) {
    # Calculate means
    mean_treated <- mean(treated[[var]], na.rm = TRUE)
    mean_control <- mean(control[[var]], na.rm = TRUE)
    
    # Perform t-test
    t_test <- t.test(treated[[var]], control[[var]], na.action = na.omit)
    
    # Extract p-value
    p_value <- t_test$p.value
    
    # Determine significance level
    significance <- case_when(p_value < significance_levels[3] ~ "***",
                              p_value < significance_levels[2] ~ "**",
                              p_value < significance_levels[1] ~ "*",
                              TRUE ~ "")
    
    # Calculate difference
    diff <- mean_treated - mean_control
    
    # Append results to balance table
    balance_table <- rbind(balance_table, data.frame(Variable = var,
                                                     Treated = mean_treated,
                                                     Control = mean_control,
                                                     Difference = diff,
                                                     `p-value`= p_value,
                                                     Significance = significance))
  }
  
  # Return balance table
  return(balance_table)
}

balance_table <- create_balance_table(data = your_data,
                                      treatment_var = treatment_assignment_variable,
                                      outcome_vars = c("variable1", "variable2", "variable3"))


