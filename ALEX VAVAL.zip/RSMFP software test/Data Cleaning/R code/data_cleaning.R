################################################


# _______________________  Task 1. Data Cleaning  _________________________

#.  Goal: Clean data, explore it, comment on anomalies prepare it for
#.        Task2.


#. Input: GEM_Baseline


#. Output: dataset_cleaned

################################################


########  0. Packages, directories  ########


# List of packages to install
list_packages <- c(
  "dplyr", "ggplot2", "tidyr", "stargazer", "haven", "tidylog", "sandwich",
  "haven", "styler", "labelled", "skimr", "ids", "uuid", "stringr",
  "pastecs", "broom","knitr","huxtable","modelsummary", "ggthemes", "data.table",
  "flextable", "officer","reporter","janitor","gt","foreign"
)


# Install if not installed and require:
for (package in list_packages) {
  if (!require(package, character.only = TRUE)) {
    install.packages(package)
    library(package, character.only = TRUE)
  } else {
    library(package, character.only = TRUE)
  }
}

options(scipen = 999) # to not have numbers in scientific format


setwd("/Users/avpc/Desktop/RSMFP software test/Data cleaning") #setting working directory


#path R folder
R_code_path <- "R code"

#path output folder
input_folder_path <- "Input"

#path output folder
output_folder_path <- "Output"

#path dataset folder 
output_dataset <- file.path(output_folder_path , "dataset")

#path documentation folder 
output_documentation <- file.path(output_folder_path , "documentation")




#________________________________________________
######## Task 1. Data cleaning  ########
#________________________________________________

#. Sections:
#.  Data exploration and notes
#. Data cleaning based on notes
#. Saving notes and data frame


  ######## Data exploration and comments  ####

# Calling datasets
data <- read_dta(file.path(input_folder_path,"GEM_Baseline.dta")) # hh survey
#view(data) # Manually inspect

labels_var_baseline <- data.frame( 
  
  look_for(data)) # dataframe with all labels and varnames

skim(data) #summary statistics to see if we have implausible values

# Exploring further:
#Checking the unique values for the variables starting with w02
unique(data$w02_paid_in_cash_job1) # These correspond to the work codes in the questionnaire
unique(data$w02_paid_in_cash_job2) # Same
unique(data$w02_paid_in_cash_job3) # Same

# Exploring the character variables listed in 5. further
unique(data$w20_hours_unpaid_job99) # A negative -900 and "."
unique(data$s02_cash_savings) # Generally looks fine but "."
unique(data$q122_father_attend_school) # need to fix 98 and ""


# Treatment status
treat_stat<- 
  read_dta(file.path(input_folder_path,"GEM_Treatment_Status.dta")) #treatment
# Only 2 variables, NO NEED FOR CLEANING WILL MERGE IN THE CONSTRUCT SESSION



# GENERAL COMMENTS:
# Based on data visualization and statistics, there are 
# a number of problems that will need to be taken care of.
# Negative values, string variables, some variables
# have the wrong type, no labels etc..

# Here are the steps I will take to clean the data:


#. 1.
# Some variables are words or string and needs to be
# transform to categorical ones and the values relabeled,
# these variables are variables that start with
# w02 and the variable w16_unpaid_job99.

#. 2.
# Some variables are character variables but should not be
# these are q122_father_attend_school , w20_hours_unpaid_job99,
# s02_cash_savings. Futhermore, some also have values that need
# to be recoded to missing.

#. 3.
# I will also need to recode some values to missing (potentially tag them) for 
# the following variables: m912_a_spouse_attend_school,
# q126_mother_attend_school, 
# s03_jewellery_savings, w07_hours_job1, w07_hours_job2,
# w07_hours_job3, m912_spouse_years_education, q104_a_tribe,
#q107_years_formal_education, q124_father_years_of_education,
# q128_mother_years_of_education, q122_father_attend_school.

#. 4.
# Some variables have negative values, that should not
# be the case, I convert them to NA but tag them.
# these variables are s04_jewellery_savings_value, w07_hours_job1,
# w07_hours_job2, w07_hours_job3

#. 5.
# Some variables will need to get labeled because the label is 
# missing, thats the case for the the variables:
#  HHID, w01_worked_yesno,w02_paid_in_cash_job2, w02_paid_in_cash_job3,
# w07_hours_job2, w07_hours_job3, m901_c_so_are_you

#.6.[IF I HAVE TIME]
# I would also want to transform to categorical variables
# the vars ending with _other, especially if there is 
# an answer that comes back often. In the interest of 
# time I write it here but do not try to fix it. 
# If I have time I will do it.

#. 7. [NEED TO DISCUSS WITH SUPERVISOR]
# Some households have missing HHID, usually happens
# when something is wrong, I need check with my
# supervisor and field coordinator to confirm.
# If nothing is wrong I will generate random
# hhids. In the absence of confirmation
# I flag them and dont use them.



  ######## Data cleaning  ########

# Creating lookup tables with codes and labels for 1.
lookup_table <- tribble(
  ~code, ~label, ~value,
  "G01", "GEM Kenchic microfranchise","1",
  "G02", "GEM Darling microfranchise", "2",
  "G03", "GEM D-Light", "3",
  "G04", "GEM PureFlow"," 4",
  "G05", "GEM Other"," 5",
  "H11", "House help/ house girl / housemaid / domestic work / washing clothes", "6",
  "H12", "Babysitting / working at a daycare"," 7",
  "H13", "Sewing / tailoring / weaving", "8",
  "H14", "Janitorial / cleaning businesses, offices, churches, etc.", "9",
  "H15", "Other work in household services and cleaning", "10",
  "R21", "Work in a cybercafé or photocopy shop", "11",
  "R22", "Hair dressing / saloon work / braiding hair", "12",
  "R23", "Working as a waitress in a hotel or restaurant", "13",
  "R24", "Bar tending", "14",
  "R25", "Selling prepared food", "15",
  "R26", "Catering work / washing dishes for hotel, restaurant or business", "16",
  "R27", "Cooking for hotel, restaurant or business", "17",
  "R28", "Working as a retail cashier / selling in a shop or kiosk", "18",
  "R29", "Other work in retail/food/service", "19",
  "N31", "Government youth work / kazi kwa vijana", "20",
  "N32", "Marketing / promotions / roadshows", "21",
  "N33", "Hawking", "22",
  "N34", "Garbage collector"," 23",
  "N35", "Casual worker in industrial work (for example, packing)", "24",
  "N36", "Sex work", "25",
  "N37", "Other work not elsewhere categorized, Professionals", "26",
  "P44", "Teacher", "27",
  "P45", "Clerical and secretarial work", "28",
  "P46", "Salaried professional (manager, accountant, legal clerk)", "29",
  "P47", "NGO field worker", "30",
  "P48", "Nurse/health technician","31",
  "P49", "Doctor", "32",
  "P50", "Police/military officer", "33",
  "P51", "Other government job", "34",
  "P52", "Computer/ electronics technician or repair", "35",
  "P53", "Other professional", "36",
  "No Paid Work", "No Paid Work", "40",
  ".","","NA",
  "..","","NA",
  "FOOD HAWKER", "other","41",
  "HOT WAITERS","other", "41")




#  Creating dataframe and dataset based on previous comments
baseline_clean <- data %>% 
  
  unique () %>% # Remove duplicates
  mutate_at(vars(w02_paid_in_cash_job1,w02_paid_in_cash_job2,
                 w02_paid_in_cash_job3), ~
              
            coalesce(
      lookup_table$value[match(., lookup_table$code)],
      .)) %>% # convert into categorical vars with new labels
  
  mutate( 
    
    across(c(q122_father_attend_school , w20_hours_unpaid_job99,
          s02_cash_savings ), ~
      
      case_when ( . == "."| . == "" | .=="98"| .=="-900" ~ NA, # or else cannot convert to numeric
                  
                  TRUE ~ .)), #Change "." to NA to be able to convert to numeric
    
    
    across(c(q122_father_attend_school , w20_hours_unpaid_job99,
             s02_cash_savings),as.numeric),#Transforming them to numeric
    
    across(c(m912_a_spouse_attend_school, q126_mother_attend_school, 
             s03_jewellery_savings, w07_hours_job1, 
             w07_hours_job2, w07_hours_job3, 
             m912_spouse_years_education, q104_a_tribe,
             q107_years_formal_education, q124_father_years_of_education,
             q128_mother_years_of_education,q122_father_attend_school), ~ 
             
             case_when( . == 98 ~ tagged_na("Dont know"),
                        . == 99 ~ tagged_na("No response"),
                        TRUE ~ .)), #mutate to missing but I tag them when needed

       across(c(s04_jewellery_savings_value, w07_hours_job1,
             w07_hours_job2, w07_hours_job3,s02_cash_savings),~
         
         case_when ( .< 0 ~ tagged_na("neg"), #most likely data entry error but tagging
                     TRUE ~.)),
       
       m912_a_spouse_attend_school =
            
            case_when( 
              
              m912_a_spouse_attend_school == 2 ~ 0,
              
              TRUE ~ m912_a_spouse_attend_school)
       
       ) %>% # Converting the 2 to 0 to be consistent with overall method of survey 
  
  separate_rows( w16_unpaid_job99, sep = ",") %>% #Here I take care of the string variable 
  #unpaid work and create dummies for each possibility
  
  mutate(w16_unpaid_job99 = as.integer(w16_unpaid_job99)) %>%
  
  mutate(dummy_variable = 1) %>%
  
  spread(key = w16_unpaid_job99, value = dummy_variable, fill = 0) %>%
  
  rename_at( vars(`1`,`2`,`3`,`4`,`5`,`6`,`7`,`8`,`<NA>`),
             ~paste0("w16_unpaid_job99_", .)) %>%
  
  select( -c(`w16_unpaid_job99_<NA>`)) %>%
  
  select(1:44, starts_with("w16_unpaid_job99_"),
         everything(.))
  
 
  # Adding labels when missing based on #5.
  # Added the labels for the new variables that I HAD to create for clarity
labels(baseline_clean) <- 
  c( HHID = "Respondent ID", w01_worked_yesno = "Have you done paid work?",
     w02_paid_in_cash_job2 = "What was the work (job2)" , 
     w02_paid_in_cash_job3 = "What was the work (job3)" ,
     w07_hours_job2 = "Hours worked last 7 days(job2)" ,
     w07_hours_job3 = "Hours worked last 7 days(job2)" ,
     m901_c_so_are_you = "Marital status",
     w16_unpaid_job99_1 = "unpaid work, cleaning house ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_2 = "unpaid work, cooking ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_3 = "unpaid work, washing utensils ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_4 = "unpaid work, caring for a child ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_5 = "unpaid work, caring for sick rel. ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_6 = "unpaid work, family business ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_7 = "unpaid work, washing clothes ( 0 =NO, 1 =YES)",
     w16_unpaid_job99_9 = "unpaid work, OTHER ( 0 =NO, 1 =YES)") # adding missing labels for variables



#Checking if data looks better than before
skim(baseline_clean) #checking if  everything is alright











  ######## Saving Note and Dataset ########

#creating a file to keep track of what I did during the cleaning
sink(file.path(output_documentation , "Comments of Data cleaning"))

# Adding comments and what i have changed to the doc
cat(" Comments and modification done in cleaning process")

cat("
# GENERAL COMMENTS:
# Based on data visualization and statistics, there are 
# a number of problems that will need to be taken care of.
# Negative values, string variables, some variables
# have the wrong type, no labels etc..

# Here are the steps I will take to clean the data:


#. 1.
# Some variables are words or string and needs to be
# transform to categorical ones and the values relabeled,
# these variables are variables that start with
# w02 and the variable w16_unpaid_job99.

#. 2.
# Some variables are character variables but should not be
# these are q122_father_attend_school , w20_hours_unpaid_job99,
# s02_cash_savings. Futhermore, some also have values that need
# to be recoded to missing.

#. 3.
# I will also need to recode some values to missing (potentially tag them) for 
# the following variables: m912_a_spouse_attend_school,
# q126_mother_attend_school, 
# s03_jewellery_savings, w07_hours_job1, w07_hours_job2,
# w07_hours_job3, m912_spouse_years_education, q104_a_tribe,
#q107_years_formal_education, q124_father_years_of_education,
# q128_mother_years_of_education, q122_father_attend_school.

#. 4.
# Some variables have negative values, that should not
# be the case, I convert them to NA but tag them.
# these variables are s04_jewellery_savings_value, w07_hours_job1,
# w07_hours_job2, w07_hours_job3

#. 5.
# Some variables will need to get labeled because the label is 
# missing, thats the case for the the variables:
#  HHID, w01_worked_yesno,w02_paid_in_cash_job2, w02_paid_in_cash_job3,
# w07_hours_job2, w07_hours_job3, m901_c_so_are_you

#.6.[IF I HAVE TIME]
# I would also want to transform to categorical variables
# the vars ending with _other, especially if there is 
# an answer that comes back often. In the interest of 
# time I write it here but do not try to fix it. 
# If I have time I will do it.

#. 7. [NEED TO DISCUSS WITH SUPERVISOR]
# Some households have missing HHID, usually happens
# when something is wrong, I need check with my
# supervisor and field coordinator to confirm.
# If nothing is wrong I will generate random
# hhids. In the absence of confirmation
# I flag them and dont use them.")



sink()

# Saving dataset
write.csv(baseline_clean,file.path(output_dataset,"baseline_clean.csv"))


