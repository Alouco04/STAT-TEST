################################################


# _______________________  Task 3. Data Analysis  _________________________

#.  Goal: Tables, graph and regression table will be made here


#. Input: job_analysis, hh_analysis, baseline_cleaned


#. Output: Table : table.pdf, 
#.         Table : regression_table.text
#.         Graph : job_type_hours_worked.pdf 

################################################


########  0. Packages, directories  ########


# List of packages to install
list_packages <- c(
  "dplyr", "ggplot2", "tidyr", "stargazer", "haven", "tidylog", "sandwich",
  "haven", "styler", "labelled", "skimr", "ids", "uuid", "stringr",
  "pastecs", "broom","knitr","huxtable","modelsummary", "ggthemes", "data.table",
  "flextable", "officer","reporter","janitor","gt","foreign","purrr","desctable",
  "kableExtra","sandwich","lmtest"

)


# Install if not installed and require:
for (package in list_packages) {
  if (!require(package, character.only = TRUE)) {
    install.packages(package)
    library(package, character.only = TRUE)
  } else {
    library(package, character.only = TRUE)
  }
}

options(scipen = 999) # to not have numbers in scientific format


setwd("/Users/avpc/Desktop/RSMFP software test/Analysis") #setting working directory


#path R folder
R_code_path <- "R code"

#path output folder
input_folder_path <- "Input"

#path output folder
output_folder_path <- "Output"

#path dataset folder 
output_tables <- file.path(output_folder_path , "Tables")

#path dataset folder 
output_plots <- file.path(output_folder_path , "Plots")

#path dataset folder 
output_reg <- file.path(output_folder_path , "Regression")


#________________________________________________
######## Task 2. Data Analysis  ########
#________________________________________________

#. Steps: 
#. In this section I will construct the required outputs


  ##### Descriptive statistics table ######

hh_analysis <- read.csv(file.path(input_folder_path,"hh_analysis.csv")) %>%
  select(-X)




desc_stat_tab<- hh_analysis %>%
  select(2:5)%>%
  desc_table(length,mean, median, sd, min, max) %>% 
  rename( 
          Variables = 1,
          Observations = 2,
          Mean = 3,
          Median = 4,
          SD =5,
          min = 6,
          max = 7) %>% 
  
  mutate(Variables =
           
           case_when(Variables =="cash_saving_usd" ~ "Savings in Cash",
                     Variables =="jewlery_saving_usd" ~ "Savings in Jewlery",
                     Variables =="total_saving_usd" ~ "Total savings",
                     TRUE ~ Variables)) %>%

  gt() %>%
  tab_header( title = "Descriptive Statistics of source and amount of Household savings") %>%
  tab_footnote(
    footnote = "Note: All the values are in USD")


  ##### Bar plot of hours worked by job_type ######

#Calling data
job_analysis <- read.csv(file.path(input_folder_path,"job_analysis.csv")) %>%
  select(-X) 

# preparing information for bar plot
graph_job<-job_analysis %>%
  group_by(treatment,job_type) %>%
  summarise(hours_w = mean(hours,na.rm=T),
            sd = sd(hours,na.rm=T))

# creating graph
# with titles, labels and so forth
# I would have added 95% confidence interval but but I do not have time.
graph <- ggplot(graph_job, aes(y = hours_w, x = factor(treatment), fill = factor(job_type))) +
  geom_bar(stat = "identity", position = "dodge")+
  scale_fill_discrete(labels=c('Paid Job 1', 'Paid Job 2','Paid Job 3', 'Unpaid work')) +
  theme_bw() +
  xlab("Treatment status") +
  ylab("Number of hours worked (on average)") +
  ggtitle(label = " Hours spent on different job types by treatment status") +
  guides(fill = guide_legend(title = "Job types")) +
  labs(caption = "Note: This table shows the average hours worked per job in the last 7 days for treated (1) and control group (0).") +
  theme(plot.caption = element_text(hjust=0))


  ######## Regression Analysis ########
# Here a simple regression with a set of variables
# will tell us what affects savings. This relationship will not be
# Causal but it will provide suggestive information through
# correlation

# What I would :
# Given that we are asked to run a model
# I would run a similar model with 
# other household characteristics. I personnally would
#not use a regression, rather a correlation matrix would
# be less cumbersom to make and easier to spot some
# some strong/ weak correlations.
# But in the interest of time, I run a simple
# regression with selected variables in the 
# dataset to show I can run regressions and
# create a regression table output



# Calling data
reg <- lm(s01_savings_for_emergency ~ q102_age  +
            
            q107_years_formal_education -1, data = hh_analysis ) # arbitrary variables, no intercept

reg_robust <- coeftest( reg,
                         
                         vcov =
                           
                           vcovHC( reg, "HC1" ) ) # Heterorobust SE 


  
  modelsummary(reg_robust,stars = c('*' = .1, '**' = .05, '***' = .01))  # seeing results to comment
  
  # Preparing for export in the other section
  regression_table <- stargazer(reg_robust, type = "text" , title = " A simple regression model of savings and human capital",
                                notes = "Notes: The outcome variable is a dummy equal to 1 if HH has cash savings for emergency. Hetero robust SE in parenthesis")
  
# Interpretation:
  # A year increase in formal education has no statistical association with the probability of having cash savings for emergency.
  #  In our model, age seems to be positively  and statistically significantly associated with the probability of having cash for
  # cash savings for emergency. This seems to be the case at the 1% confidence level. Interpreted literally, a 1 year increase in
  # age is associated with a 3.3 percentage point increase in the probability of having cash savings for emergency.






    ######## Saving and exporting outputs ########
  
 gtsave(desc_stat_tab,file.path(output_tables ,"Tables.pdf"))

 ggsave(file.path(output_plots ,"job_type_hours_worked.pdf"))
 
 writeLines(regression_table,file.path(output_reg ,"regression_table.txt"))


